package Main;
import Main.Game.Memorygame;

import javax.swing.*;

public class Mainclass {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Program 8");
        Memorygame game = new Memorygame();

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800,800);
        frame.setContentPane(game.getPanel());
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

    }
}
