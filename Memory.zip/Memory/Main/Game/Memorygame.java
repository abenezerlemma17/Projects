//Abenezer Lemma


package Main.Game;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;

public class Memorygame {
    // this here is where I create all my variables that I will for my program
    private JComboBox comboBox;
    private JButton restbutton;
    private JLabel buttonlabel;
    private JLabel moveslabel;
    private JPanel Panel1;
    private JPanel Panel2;
    private JPanel MainPanel;
    private JButton firstcard = null;
    private JButton secondcard = null;
    private Timer timer;
    private JButton selectedCard;

    private boolean waiting = false;
    private int moves = 0;



    public Memorygame() {
        // Panel 2 and 1 is how I seperate my code so that my everytime I press new-game it doesnt rest the Entire page
        Panel2 = new JPanel();
        Panel1 = new JPanel();
        String[] list = {"4x4", "6x6", "8x8"};
        // this is where I set a value for Panel 1 which is the top panel
        comboBox = new JComboBox(list);
        restbutton = new JButton("New Game: ");
        moveslabel = new JLabel("Moves: " + moves);
        buttonlabel = new JLabel("Board: ");
//      and this is where I add them
        Panel2.add(moveslabel);
        Panel2.add(buttonlabel);
        Panel2.add(comboBox);
        Panel2.add(restbutton);
        restbutton.addActionListener(e -> Game());
        // Here i set an Action listener so when the rest button which is also new game is pressed
        // it goes straight to the class game

    }

    private void Game() {
        Panel1.removeAll();
        //so when the rest button is pressed it removes everything and redisplays it
        moves = 0;
        // here is where we and get a grid layout
                String getmatrix = (String) comboBox.getSelectedItem();
                int matrix_size;

                if (getmatrix.equals("4x4")) {
                    matrix_size = 4;
                }

                else if (getmatrix.equals("6x6")) {
                    matrix_size = 6;
                }

                else  {
                    matrix_size = 8;
                }

                Panel1.setLayout(new GridLayout(matrix_size, matrix_size));

                // here is I get my pairs of numbers according to the total numbers
                int total_cards = matrix_size * matrix_size;
                int half_cards = total_cards / 2;

            int [] pairs = new int[total_cards];
            // here I use a and integer array and chnage it to a array list shuffle it and change andd back to the array
            ArrayList<Integer> list = new ArrayList<>();
            for (int i = 0; i < half_cards; i++) {
                list.add(i);
                list.add(i);
            }

                Collections.shuffle(list);
                for (int i = 0; i < pairs.length; i++) {
                    pairs[i] = list.get(i);
                    }
// here is where the main code works where I check if the cards are equal and check if there are not took me a while to figure out where to put it
               for (int i = 0; i < pairs.length; i++) {
                   JButton cards_flipping = new JButton("Click to flip");
                  final int val = pairs[i];
                  cards_flipping.addActionListener(e ->  {
                      selectedCard = (JButton) e.getSource();

                      if (timer != null && timer.isRunning()){return;}
                      if(selectedCard == firstcard) {return;}

                      selectedCard.setText(String.valueOf(val));
                      if (firstcard == null) {
                          firstcard = selectedCard;
                      }

                      else {
                          secondcard = selectedCard;
                          moves++;
                          moveslabel.setText("Moves: " + moves);
                      }

                      if (firstcard.getText().equals(secondcard.getText())) {
                          firstcard.setEnabled(false);
                          secondcard.setEnabled(false);
                          firstcard = null;
                          secondcard = null;
                          waiting = false;

                      }
                      else  {
                          waiting = true;
                          timer = new Timer(500, new ActionListener() {
                              @Override
                              public void actionPerformed(ActionEvent e) {
                                  firstcard.setText("Click to flip");
                                  secondcard.setText("Click to flip");
                                  firstcard = null;
                                  secondcard = null;
                              }
                          });
                          timer.setRepeats(false);
                          timer.start();
                      }
                          });
                   Panel1.add(cards_flipping);
               }

        Panel1.repaint();
        Panel1.revalidate();

    }


    public JPanel getPanel() {
        // this is how I was able to seperate my top and lower panel
        MainPanel = new JPanel();
        MainPanel.setLayout(new BorderLayout());
        MainPanel.add(Panel2, BorderLayout.NORTH);
        MainPanel.add(Panel1, BorderLayout.CENTER);
        return MainPanel;
    }


}