#ifndef SHARED_PROTOCOL_H
#define SHARED_PROTOCOL_H

// Protocol Constants
// This file defines constants shared between client and server

// Message and nickname limits
#define MAX_MESSAGE_LENGTH 512
#define MAX_NICK_LENGTH 16
#define MAX_LINE 1024
#define MAX_CLIENTS 20

// Error codes sent by server
#define ERR_INVALID_NICK    401
#define ERR_NICK_IN_USE     402
#define ERR_NOT_REGISTERED  403
#define ERR_NO_SUCH_USER    404
#define ERR_MESSAGE_TOO_LONG 405
#define ERR_UNKNOWN_COMMAND 406

// Command strings
#define CMD_NICK  "NICK"
#define CMD_MSG   "MSG"
#define CMD_DM    "DM"
#define CMD_WHO   "WHO"
#define CMD_PING  "PING"
#define CMD_QUIT  "QUIT"
#define CMD_STATS "STATS"

// Response strings
#define RSP_USERS "USERS"
#define RSP_PONG  "PONG"
#define RSP_OK    "OK"
#define RSP_ERR   "ERR"

#endif
