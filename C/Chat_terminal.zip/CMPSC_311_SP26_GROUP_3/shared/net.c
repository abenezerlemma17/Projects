#define _POSIX_C_SOURCE 200112L

#include "net.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>


// Fixed a bug to where I placed the close(sockfd) command to close the socket and connection in the 
// create_client_socket() function & create_listening_socket() function. This prevented the client side
// to actually connect correctly!

int extract_line(char *buf, size_t *len, char *line_out, size_t line_cap)
{
    if (buf == NULL || len == NULL || line_out == NULL || line_cap == 0) {
        return 0;
    }

    // Find newline in the valid portion of the buffer
    size_t newline_index = 0;
    int found = 0;
    for (size_t i = 0; i < *len; i++) {
        if (buf[i] == '\n') {
            newline_index = i;
            found = 1;
            break;
        }
    }

    // No complete line yet
    if (!found) {
        return 0;
    }

    // Copy through the newline into line_out
    size_t copy_len = newline_index + 1;

    // Need room for copied chars plus null terminator
    if (copy_len >= line_cap) {
        return 0;
    }

    memcpy(line_out, buf, copy_len);
    line_out[copy_len] = '\0';

    // Shift remaining buffer contents left
    size_t remaining = *len - copy_len;
    memmove(buf, buf + copy_len, remaining);
    buf[remaining] = '\0';

    // Update length to remaining bytes in buffer
    *len = remaining;

    return 1;
}

int create_client_socket(const char *host, int port)
{
    if(host == NULL || port <= 0) { // Check for valid host and port
        printf("Improper Host or Port\n");
        return -1;
    }

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0) // Checks for socket failure
    { 
        printf("Socket failed\n");
        return -1;
    }

    struct sockaddr_in server_addr;

    memset(&server_addr, 0, sizeof(server_addr)); // Fill server_addr with zeros
    server_addr.sin_family = AF_INET; // Set address family to IPv4
    server_addr.sin_port = htons(port); // Convert port number to network byte order

    if (inet_pton(AF_INET, host, &server_addr.sin_addr) <= 0) // Convert host to address
    {
        printf("Invalid Host\n");
        close(sockfd);
        return -1;
    }

    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) // Connect to the server
    {
        printf("Connect failed\n");
        close(sockfd); // Close the socket after use
        return -1;
    }

    return sockfd;

}

int create_listening_socket(int port)
{
    if (port <= 0)
    {
        printf("Invalid port\n");
        return -1;
    }

    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        printf("Socket failed\n");
        return -1;
    }

    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        printf("Bind failed\n");
        close(sockfd);
        return -1;
    }

    if (listen(sockfd, 5) < 0)
    {
        printf("Listen failed\n");
        close(sockfd);
        return -1;
    }

    return sockfd;
}

int format_sockaddr(char *out, size_t out_sz, const struct sockaddr_in *addr)
{
    if(addr == NULL) // Checks if addr is NULL
    {
        printf("Invalid address\n");
        return 0;
    }

    char *ip = inet_ntoa((*addr).sin_addr); // Convert the IP address to a string
    int port = ntohs((*addr).sin_port); // Convert the port number to host byte order

    snprintf(out, out_sz, "%s:%d", ip, port); // Combines the IP address and port number into the output buffer
    printf("Formatted sockaddr: %s\n", out);

    return 1;
}
ssize_t send_all(int fd, const char *buf, size_t len)
{
    if (buf == NULL || len == 0)
    {
        return 0; // Nothing to send
    }

    size_t total_sent = 0;
    while (total_sent < len)
    {
        ssize_t sent = send(fd, buf + total_sent, len - total_sent, 0);

        if (sent < 0)
        {
            if (errno == EINTR)
            {
                continue;   // try again if interrupted
            }
            return -1;
        }

        if (sent == 0)
        {
            return -1;
        }

        total_sent += (size_t)sent;
    }

    return (ssize_t)total_sent;
}

ssize_t send_line(int fd, const char *line) {

    if (line == NULL) {
        return -1; // Invalid input
    }
    size_t len = strlen(line);

    if(len > 0 && line[len - 1] == '\n') {
        return send_all(fd, line, len);
    }
    else
    {
     char *buffer = malloc(len + 2);
     if (buffer == NULL) 
     {
        return -1;       
     }

     memcpy(buffer, line, len);
     buffer[len] = '\n';
     buffer[len + 1] = '\0';

     ssize_t result = send_all(fd, buffer, len + 1);
     free(buffer);
    
    return result;
    }
}