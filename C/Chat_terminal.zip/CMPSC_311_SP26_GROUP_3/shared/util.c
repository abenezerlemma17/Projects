#include "util.h"
#include "protocol.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/socket.h>
#include <ctype.h>
#include <time.h>
#include <limits.h>
#include <stdbool.h>

void die(const char *msg)
{
    if (msg != NULL)
    {
        perror(msg);
    }
    else
    {
        perror("Fatal error");
    }
    exit(EXIT_FAILURE);
}

int split_first_word(char *line, char **cmd, char **rest)
{
    int cmd_end_index = 0;
    bool cmd_encounter = false;
    int cmd_index = 0;

    for (int i = 0; line[i] != '\0'; i++) // Iterates through the input line and splits the first word and the rest of the line
    {
        if (line[i] != ' ' && !cmd_encounter)
        {
            cmd_encounter = true;
        }
        if (cmd_encounter)
        {
            (*cmd)[cmd_index] = line[i];
            if (line[i] == ' ')
            {
                cmd_end_index = i;
                (*cmd)[cmd_index] = '\0';
                break;
            }
            cmd_index++;
        }
    }

    if (strcmp(*cmd, CMD_DM) != 0 && strcmp(*cmd, CMD_MSG) != 0 && strcmp(*cmd, CMD_WHO) != 0 && strcmp(*cmd, CMD_STATS) != 0 && strcmp(*cmd, CMD_NICK) != 0 && strcmp(*cmd, CMD_QUIT) != 0 && strcmp(*cmd, CMD_PING) != 0) // If the inputted command is not a listed command, return 0, else continue
    {
        return 0;
    }

    int rest_index = 0;
    for (int i = cmd_end_index + 1; line[i] != '\0'; i++) // Iterates through the rest of the line and stores it in rest
    {
        (*rest)[rest_index] = line[i];
        rest_index++;
    }
    (*rest)[rest_index] = '\0';

    printf("cmd -> %s\n", *cmd);
    printf("rest -> %s\n", *rest);

    return 1;
}

void chomp_crlf(char *str)
{

    ssize_t message_length = strlen(str);

    while (message_length > 0 && (str[message_length - 1] == '\n' || str[message_length - 1] == '\r'))
    {
        str[message_length - 1] = '\0';
        message_length--;
    }
}

bool valid_nick(const char *nick)
{
    if (nick == NULL){
        return false;
    }

    // idk how errors are supposed to be raised

    int nickLen = strlen(nick);

    if (nickLen < 1 || nickLen > MAX_NICK_LENGTH)
    {
        char nickLenMsg[MAX_LINE];
        snprintf(nickLenMsg, sizeof(nickLenMsg), "ERROR %d INVALID NICK LENGTH", ERR_INVALID_NICK);
        return false;
    }

    for (int i = 0; i < nickLen; i++)
    {
        char cur = nick[i];
        if (!((cur >= 'a' && cur <= 'z') || (cur >= 'A' && cur <= 'Z') || (cur >= '0' && cur <= '9') || cur == '_' || cur == '-'))
        {
            char nickLenMsg[MAX_LINE];
            snprintf(nickLenMsg, sizeof(nickLenMsg), "ERROR %d INVALID CHARACTER IN NICK", ERR_INVALID_NICK);
            return false;
        }
    }

    return true;
}

int split_two_words(char *line, char **cmd, char **nick, char **rest)
{

    int cmd_end_index = 0;
    int nick_end_index = 0;

    int cmd_index = 0;
    int nick_index = 0;

    bool cmd_encounter = false;
    bool nick_encounter = false;

    for (int i = 0; line[i] != '\0'; i++) // Iterates through the input line and splits the first word and the rest of the line
    {
        if (line[i] != ' ' && !cmd_encounter)
        {
            cmd_encounter = true;
        }
        if (cmd_encounter)
        {
            (*cmd)[cmd_index] = line[i];
            if (line[i] == ' ')
            {
                cmd_end_index = i;
                (*cmd)[cmd_index] = '\0';
                break;
            }
            cmd_index++;
        }
    }

    for (int i = cmd_end_index + 1; line[i] != '\0'; i++) // Iterates through the input line and splits the second word and the rest of the line
    {
        if (line[i] != ' ' && !nick_encounter)
        {
            nick_encounter = true;
        }
        if (nick_encounter)
        {
            (*nick)[nick_index] = line[i];
            if (line[i] == ' ')
            {
                nick_end_index = i;
                (*nick)[nick_index] = '\0';
                break;
            }
            nick_index++;
        }
    }

    int rest_index = 0;
    for (int i = nick_end_index + 1; line[i] != '\0'; i++) // Iterates through the rest of the line and stores it in rest
    {
        (*rest)[rest_index] = line[i];
        rest_index++;
    }
    (*rest)[rest_index] = '\0';

    printf("cmd -> %s\n", *cmd);
    printf("nick -> %s\n", *nick);
    printf("rest -> %s\n", *rest);

    if (strcmp(*cmd, CMD_DM) == 0) // If word and nick exists return 2, if only word exists return 1, else 0
    {
        if (strcmp(*nick, "") == 0 && valid_nick(*nick) == true)
        {
            return 2;
        }
        else
        {
            return 1;
        }
    }
    else
    {
        return 0;
    }
}
void server(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./server <port>");
    }

    char *endptr;
    errno = 0;
    long N = strtol(argv[1], &endptr, 10);

    if (argv[1] == endptr)
    {
        die("Use int values only");
    }

    if (((errno == ERANGE && (N == LONG_MAX || N == LONG_MIN)) || (errno != 0 && N == 0)))
    {
        die("Out of range");
    }
}

void client(int argc, char *argv[])
{
    if (argc != 4)
    {
        printf("Usage: ./client <user> <host> <port>");
    }

    char *endptr;
    errno = 0;
    long N = strtol(argv[3], &endptr, 10);

    if (argv[3] == endptr)
    {
        die("Use int values only");
    }

    if (((errno == ERANGE && (N == LONG_MAX || N == LONG_MIN)) || (errno != 0 && N == 0)))
    {
        die("Out of range");
    }
}

int format_log_line(char *out, size_t out_sz, const char *event_text)
{
    time_t now = time(NULL);
    struct tm *t = localtime(&now);

    // Each if statment ensures a 0 is added in front of a corresponding time if needed
    char month[32];
    if ((*t).tm_mon + 1 < 10)
    {
        snprintf(month, sizeof(month), "0%d", (*t).tm_mon + 1);
    }
    else
    {
        snprintf(month, sizeof(month), "%d", (*t).tm_mon + 1);
    }

    char day[32];
    if ((*t).tm_mday + 1 < 10)
    {
        snprintf(day, sizeof(day), "0%d", (*t).tm_mday);
    }
    else
    {
        snprintf(day, sizeof(day), "%d", (*t).tm_mday);
    }

    char hr[32];
    if ((*t).tm_hour < 10)
    {
        snprintf(hr, sizeof(hr), "0%d", (*t).tm_hour);
    }
    else
    {
        snprintf(hr, sizeof(hr), "%d", (*t).tm_hour);
    }

    char min[32];
    if ((*t).tm_min < 10)
    {
        snprintf(min, sizeof(min), "0%d", (*t).tm_min);
    }
    else
    {
        snprintf(min, sizeof(min), "%d", (*t).tm_min);
    }

    char sec[32];
    if ((*t).tm_sec < 10)
    {
        snprintf(sec, sizeof(sec), "0%d", (*t).tm_sec);
    }
    else
    {
        snprintf(sec, sizeof(sec), "%d", (*t).tm_sec);
    }

    snprintf(out, out_sz, "%d-%s-%s %s:%s:%s %s\n", (*t).tm_year + 1900, month, day, hr, min, sec, event_text);
    printf("%s", out);

    return 1;
}

// start_with_command CODE (START OF CODE!)

// Another function created in order to check for command prefix
bool starts_with(const char *s, const char *prefix)
{
    // Return false if s or the prefix is NULL
    if (s == NULL || prefix == NULL)
    {
        return false;
    }

    // Return true if any of the prefix is empty.
    // Since prefix is a pointer (similar to an array), we need to use the [#] in order to check
    // inside a pointer.
    if (prefix[0] == '\0')
    {
        return true;
    }

    // Return true if s begins exactly with the prefix
    // We had to look for the size of the prefix since that will change depending on
    // the command given by the user.
    size_t prefix_length = strlen(prefix); // This code finds how long the prefix is!

    // This 'if' statement checks if 's' is smaller than the prefix length
    if (strlen(s) < prefix_length)
    {
        return false;
    }

    // This line compares the first 'prefix_length' characters of 's' with 'prefix' itself
    // If both 'prefix_length' and 'prefix' are the same, it returns true.
    if (strncmp(s, prefix, prefix_length) == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

// END OF start_with_command CODE!!!

// trim_spaces CODE (START OF CODE!)

void trim_spaces(char *s)
{
    if (s == NULL) // Safety handle if nothing is in the string!
    {
        return;
    }

    // Creating variables to use to find the beginning and end of a string!
    int start = 0;
    int end = strlen(s); // Looks up the whole length of the string!

    if (end == 0) // Another saftey handle if nothing is in string to trim!
    {
        return;
    }

    // This while loop is here to check if a string has spaces at the beginning of a string. If there
    // is spaces at the beginning, it will keep moving up until a character is found!
    // This is possible with arrays! We increment forward using 'start++'!
    while (s[start] == ' ')
    {
        start++; // Increment forward at the beginning of string!
    }

    // This while loop is checking if there are spaces at the end of a string. If there is spaces at the
    // end, it will keep moving backwards until a character is found!. This is possible with
    // s[end - 1] == ' '. With 'end > start', this is a saftey handle just in case if the string isn't
    // only spaces. We increment backwards with 'end--'!
    while (end > start && s[end - 1] == ' ')
    {
        end--; // Increment backwards at the end of string!
    }

    // Created another variable to store the new and improved string inside!
    int new_string = 0;

    // *** This while loop copies characters from the trimmed part into the front of the same string.
    while (start < end)
    {
        s[new_string] = s[start];
        new_string++;
        start++;
    }

    // As soon as the program checks to see it's at the end of a string while taking care of the other
    // trailing spaces, it will end the program for the user!
    s[new_string] = '\0';
}

// END OF trim_spaces CODE!!!
