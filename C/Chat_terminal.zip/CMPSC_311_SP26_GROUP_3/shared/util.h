#ifndef UTIL_H
#define UTIL_H

#include <stddef.h>
#include <sys/types.h>
#include <stdbool.h>
#include <netinet/in.h>

int format_sockaddr(char *out, size_t out_sz, const struct sockaddr_in *addr);
int extract_line(char *buf, size_t *len, char *line_out, size_t line_cap);
int split_first_word(char *line, char **cmd, char **rest);
int split_two_words(char *line, char **cmd, char **nick, char **rest);
void chomp_crlf(char *str);
bool valid_nick(const char *nick);
void die(const char *msg);
void client(int argc, char *argv[]);
void server(int argc, char *argv[]);
int format_log_line(char *out, size_t out_sz, const char *event_text);
void trim_spaces(char *s);
bool starts_with(const char *s, const char *prefix);

#endif
