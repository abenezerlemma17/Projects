#ifndef NET_H
#define NET_H

#include <stddef.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

int extract_line(char *buf, size_t *len, char *line_out, size_t line_cap);
int create_client_socket(const char *host, int port);
int create_listening_socket(int port);
int format_sockaddr(char *out, size_t out_sz, const struct sockaddr_in *addr);
ssize_t send_all(int fd, const char *buf, size_t len);
ssize_t send_line(int fd, const char *line);

#endif
