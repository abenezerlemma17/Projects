# Team Notes

## Communication
-We will use Slack for quick questions

## Decisions
-
