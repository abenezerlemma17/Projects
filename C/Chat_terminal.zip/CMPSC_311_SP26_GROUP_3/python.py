import socket
import threading
import time


def receive_loop(sock: socket.socket) -> None:
    """Continuously read newline-delimited messages from the server."""
    buffer = ""

    try:
        while True:
            data = sock.recv(4096)
            if not data:
                print("\n[server disconnected]")
                break

            buffer += data.decode("utf-8", errors="replace")

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                print(f"\n[server] {line}")
                print("\nEnter choice (1-8): ", end="", flush=True)

    except OSError:
        print("\n[connection closed]")


def send_line(sock: socket.socket, line: str) -> bool:
    """Send one protocol line to the server."""
    try:
        sock.sendall((line + "\n").encode("utf-8"))
        print(f"[sent] {line}")
        return True
    except OSError as e:
        print(f"Send error: {e}")
        return False


def run_scripted_test(sock: socket.socket, test_name: str, commands: list[str], delay: float = 0.5) -> bool:
    """Run a scripted sequence of protocol commands."""
    print(f"\n--- Running test: {test_name} ---")
    for command in commands:
        ok = send_line(sock, command)
        if not ok:
            return False
        time.sleep(delay)
    print(f"--- Finished test: {test_name} ---\n")
    return True


def print_menu() -> None:
    print("\nChoose an option:")
    print("  1. Set nickname")
    print("  2. Send public message")
    print("  3. Send direct message")
    print("  4. List users (WHO)")
    print("  5. Send ping")
    print("  6. Send raw command")
    print("  7. Run scripted tests")
    print("  8. Quit")


def print_test_menu() -> None:
    print("\nScripted tests:")
    print("  1.  Basic happy path")
    print("  2.  Malformed commands")
    print("  3.  Ping tests")
    print("  4.  Pre-NICK error tests")
    print("  5.  Bad nickname rules (ERR 402)")
    print("  6.  DM to unknown user (ERR 404)")
    print("  7.  QUIT sequence")
    print("  8.  MSG broadcast flow")
    print("  9.  PING exact token echo")
    print("  10. Unknown commands (ERR 400)")
    print("  11. Run all")
    print("  12. Back")


def prompt_connection() -> tuple[str, int]:
    """Prompt user for IP and port."""
    while True:
        host = input("Enter server IP (default 127.0.0.1): ").strip()
        if not host:
            host = "127.0.0.1"

        port_str = input("Enter port: ").strip()

        try:
            port = int(port_str)
            return host, port
        except ValueError:
            print("Invalid port. Please enter a number.\n")


def handle_scripted_tests(sock: socket.socket) -> bool:
    """Display the scripted test menu and run selected tests."""
    tests = {
        "1": (
            "Basic happy path",
            [
                "NICK testuser",
                "WHO",
                "PING token123",
                "MSG hello everyone",
            ],
        ),
        "2": (
            "Malformed commands",
            [
                "BADCOMMAND",
                "NICK",
                "MSG",
                "PING",
                "DM",
                "DM bob",
            ],
        ),
        "3": (
            "Ping tests",
            [
                "PING abc",
                "PING 12345",
                "PING token_test",
            ],
        ),
        "4": (
            "Pre-NICK error tests",
            [
                "WHO",
                "MSG should fail before nick",
                "DM bob hello before nick",
            ],
        ),
        # ── New tests ────────────────────────────────────────────────────────────
        "5": (
            # Spec §8: nick length 1-16, allowed chars A-Z a-z 0-9 _.
            # All four commands below should receive ERR 402 BAD_NICK.
            "Bad nickname rules (ERR 402)",
            [
                "NICK toolongnickname1234",   # 20 chars — exceeds 16-char limit
                "NICK bad-nick",              # hyphen is not an allowed character
                "NICK bad@nick",              # @ is not an allowed character
                "NICK has space",             # space is not an allowed character
                "NICK ",                      # missing name after keyword → ERR 401 or 402
            ],
        ),
        "6": (
            # Spec §9 DM: if the target nickname is not connected → ERR 404 NO_SUCH_NICK.
            # We first set a valid nick so the DM command is not blocked by ERR 409.
            "DM to unknown user (ERR 404)",
            [
                "NICK dmtester",
                "DM ghost_user hello there",   # ghost_user does not exist → ERR 404
                "DM nobody hi",                # another non-existent target
            ],
        ),
        "7": (
            # Spec §9 QUIT: server responds OK, broadcasts LEAVE <name>, closes conn.
            # After QUIT the connection will be closed server-side; subsequent sends
            # will fail, which is the expected and correct behaviour.
            "QUIT sequence",
            [
                "NICK quitter",
                "QUIT",                        # server: OK  →  broadcast: LEAVE quitter
            ],
        ),
        "8": (
            # Spec §9 MSG: server responds OK and broadcasts MSG <name> <text> to all.
            # Multi-word and Unicode-friendly text should both work.
            "MSG broadcast flow",
            [
                "NICK broadcaster",
                "MSG hello from the broadcast test",   # normal multi-word message
                "MSG second message with more words",  # second broadcast from same nick
            ],
        ),
        "9": (
            # Spec §7: PONG must echo the token *exactly* — case, digits, underscores.
            # Does not require a nick (recommended by spec).
            "PING exact token echo",
            [
                "PING UPPERCASE_TOKEN",    # server must reply PONG UPPERCASE_TOKEN
                "PING lower_case_123",     # server must reply PONG lower_case_123
                "PING MiXeD_cAsE_456",    # server must reply PONG MiXeD_cAsE_456
            ],
        ),
        "10": (
            # Spec §3: any unknown command token → ERR 400 BAD_COMMAND.
            "Unknown commands (ERR 400)",
            [
                "HELLO",           # not a valid command
                "KICK someone",    # not in command grammar
                "STATUS",          # not in command grammar
                "LIST",            # not in command grammar
                "JOIN room",       # not in command grammar (server-side broadcast word)
            ],
        ),
    }

    while True:
        print_test_menu()
        choice = input("Enter test choice (1-12): ").strip()

        if choice in tests:
            test_name, commands = tests[choice]
            if not run_scripted_test(sock, test_name, commands):
                return False
            # QUIT (test 7) closes the server connection — returning False here
            # exits the test menu AND the main loop so the dead socket is never reused.
            if choice == "7":
                print("[info] QUIT sent — server closed the connection. Restart to reconnect.")
                return False

        elif choice == "11":
            # QUIT (test 7) closes the server connection, so it must run last.
            # All other tests run first in their natural order; QUIT is appended at the end.
            run_all_order = [k for k in tests if k != "7"] + ["7"]
            for key in run_all_order:
                test_name, commands = tests[key]
                if not run_scripted_test(sock, test_name, commands):
                    return False
            # QUIT was the final test; connection is now closed — exit cleanly.
            print("[info] Run all complete. QUIT sent — server closed the connection. Restart to reconnect.")
            return False

        elif choice == "12":
            return True

        else:
            print("Invalid choice.")


def main() -> None:
    host, port = prompt_connection()

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((host, port))
    except OSError as e:
        print(f"Connection error: {e}")
        return

    print(f"\nConnected to {host}:{port}")

    recv_thread = threading.Thread(target=receive_loop, args=(sock,), daemon=True)
    recv_thread.start()

    try:
        while True:
            print_menu()
            choice = input("Enter choice (1-8): ").strip()

            if choice == "1":
                name = input("Enter nickname: ").strip()
                if not name:
                    print("Nickname cannot be empty.")
                    continue
                if not send_line(sock, f"NICK {name}"):
                    break

            elif choice == "2":
                text = input("Enter public message: ")
                if not text.strip():
                    print("Message cannot be empty.")
                    continue
                if not send_line(sock, f"MSG {text}"):
                    break

            elif choice == "3":
                target = input("Enter recipient nickname: ").strip()
                text = input("Enter direct message: ")
                if not target or not text.strip():
                    print("Recipient and message are required.")
                    continue
                if not send_line(sock, f"DM {target} {text}"):
                    break

            elif choice == "4":
                if not send_line(sock, "WHO"):
                    break

            elif choice == "5":
                token = input("Enter ping token (no spaces): ").strip()
                if not token or " " in token:
                    print("Invalid token.")
                    continue
                if not send_line(sock, f"PING {token}"):
                    break

            elif choice == "6":
                raw = input("Enter raw protocol command: ").strip()
                if not raw:
                    print("Command cannot be empty.")
                    continue
                if not send_line(sock, raw):
                    break

            elif choice == "7":
                if not handle_scripted_tests(sock):
                    break

            elif choice == "8":
                send_line(sock, "QUIT")
                break

            else:
                print("Invalid choice.")

    except (KeyboardInterrupt, EOFError):
        print("\nExiting.")

    finally:
        try:
            sock.close()
        except OSError:
            pass


if __name__ == "__main__":
    main()