/*
 * main.c - Chat client lifecycle management
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <errno.h>

#include "../shared/net.h"
#include "../shared/util.h"
#include "../shared/protocol.h"
#include "../server/src/broadcast.h"
#include "io.h"

volatile int connection_closed = 0;

// This function job is to keep listening for messages sent by the server
// and print them to the terminal for the user to see them!

static void *server_reader_thread(void *arg)
{
    // The variable 'sockfd' get the socket number out of the pointer that was passed into the thread
    int sockfd = *(int *)arg;

    char buffer[1024];
    ssize_t space;

    // This while loop will keep running until the server closes by user or by an error.
    while (1)
    {
        space = recv(sockfd, buffer, sizeof(buffer) - 1, 0);

        if (space == 0)
        {
            connection_closed = 1;
            break;
        }

        if (space < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }

            perror("Error! Couldn't receive message from the server. Please try again");
            break;
        }

        buffer[space] = '\0';
        
        printf("%s", buffer);
        fflush(stdout);
    }

    return NULL;
}

int main(int argc, char **argv)
{

    // These two pointers will store the command-line arguments.
    const char *host;
    const char *nick;

    // This variable will store the port number.
    int port_num;

    int max = 4;

    int sockfd;
    pthread_t reader_thread;

    // This buffer stores what the user types in the terminal.
    char input[MAX_LINE];
    // This buffer stores the final protocol line that gets sent to the server.
    char output[MAX_LINE];

    // A flag variable that will help stop the loop after the command '/quit' is sent by user!
    int quit_requested = 0;

    // Safety Handle! If the amount of command arguments is anything other than the max, it will
    // throw an error!
    if (argc != max)
    {
        fprintf(stderr, "Usage: %s <host> <port> <nickname>\n", argv[0]);
        return 1;
    }

    host = argv[1];
    port_num = atoi(argv[2]); // Converting the port number string into an integer
    nick = argv[3];

    // Safety check to check if the port number is a positive number.
    if (port_num <= 0)
    {
        fprintf(stderr, "Error! Invalid port number.\n");
        return 1;
    }

    // Safety check to see if the nickname is empty or longer than MAX_NICK_LENGTH.
    if (strlen(nick) == 0 || strlen(nick) > MAX_NICK_LENGTH)
    {
        fprintf(stderr, "Error! Invalid nickname length.\n");
        return 1;
    }

    // This line creates a client socket and connects it to the server.
    sockfd = create_client_socket(host, port_num);

    // This if statement checks that if the connection failed, it will stop the program.
    if (sockfd < 0)
    {
        fprintf(stderr, "Failed to connect to %s:%d\n", host, port_num);
        return 1;
    }

    snprintf(output, sizeof(output), "NICK %s\n", nick);
    if (send_all(sockfd, output, strlen(output)) < 0)
    {
        perror("Error! Failed to send NICK command");
        close(sockfd);
        return 1;
    }    

    // This if statement starts a second thread that will keep reading messages from the server.
    if (pthread_create(&reader_thread, NULL, server_reader_thread, &sockfd) != 0)
    {
        perror("pthread_create");
        close(sockfd);
        return 1;
    }    
    sleep(1);

    // This while loop keeps reading input from the user until they manually quit.
    while (!quit_requested && !connection_closed)
    {   
        if(fgets(input, sizeof(input), stdin) == NULL)
        {
            fprintf(stderr, "Input Error");
            break;
        }

        if (input_to_protocol(output, sizeof(output), input) != 0)
        {
            fprintf(stderr, "Invalid command.\n");
            continue;
        }

        if (send_all(sockfd, output, strlen(output)) < 0)
        {
            fprintf(stderr, "Failed to send message to server.\n");
            break;
        }

        if (strcmp(output, "QUIT\n") == 0)
        {
            quit_requested = 1;
            break;
        }
    }
    shutdown(sockfd, SHUT_RDWR);
    pthread_join(reader_thread, NULL);
    close(sockfd);

    return 0;
}
