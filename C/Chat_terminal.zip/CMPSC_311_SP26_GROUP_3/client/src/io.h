#ifndef IO_H
#define IO_H

#include <stddef.h>

int build_nick_command(char *out, size_t out_sz, const char *nick);
int build_msg_command(char *out, size_t out_sz, const char *text);
int build_dm_command(char *out, size_t out_sz, const char *text, const char *nick);
int build_ping_command(char *out, size_t out_sz, const char *token);
int input_to_protocol(char *out, size_t out_sz, char *input);

#endif
