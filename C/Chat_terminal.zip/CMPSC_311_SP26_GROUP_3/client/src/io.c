#include "io.h"
#include "util.h"
#include "../shared/protocol.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <stddef.h>
#include <ctype.h>

// BUILD FUNCTIONS USE CMD CONSTANTS INSIDE OF OUT

bool valid_nick(const char *nick);

// build nick command, returns "NICK <nick>\n"
int build_nick_command(char *out, size_t out_sz, const char *nick)
{

    if ((nick != NULL) && (valid_nick(nick)))
    {
        snprintf(out, out_sz, "%s %s\n", CMD_NICK, nick);
        return 1;
    }
    else
    {
        return 0;
    }
}

// build msg command, returns "MSG <text>\n"
int build_msg_command(char *out, size_t out_sz, const char *text)
{

    if ((text != NULL) && (strlen(text) > 0) && (strlen(text) <= MAX_MESSAGE_LENGTH))
    {
        snprintf(out, out_sz, "%s %s\n", CMD_MSG, text);
        return 1;
    }
    else
    {
        return 0;
    }
}

// build msg command, returns "DM NICK <text>\n"
int build_dm_command(char *out, size_t out_sz, const char *text, const char *nick)
{

    if (nick != NULL && valid_nick(nick) && text != NULL && strlen(text) > 0 && (strlen(text) <= MAX_MESSAGE_LENGTH))
    {
        snprintf(out, out_sz, "%s %s %s\n", CMD_DM, nick, text);
        return 1;
    }
    else
    {
        return 0;
    }
}

// build simple command, returns "WHO\n" or "QUIT\n"
int build_simple_command(char *out, size_t out_sz, const char *cmd)
{
    if (cmd != NULL && (strcmp(cmd, CMD_QUIT) == 0 || strcmp(cmd, CMD_WHO) == 0))
    {
        snprintf(out, out_sz, "%s\n", cmd);
        return 1;
    }
    else
    {
        return 0;
    }
}

// build ping command, return "PING <token>\n"
int build_ping_command(char *out, size_t out_sz, const char *token)
{
    if (token != NULL && strlen(token) > 0)
    {
        snprintf(out, out_sz, "%s %s\n", CMD_PING, token);
        return 1;
    }
    else
    {
        return 0;
    }
}

int input_to_protocol(char *out, size_t out_sz, char *input)
{
    // Creating my variables!
    size_t length;

    // Safety check if either string is missing or the output buffer size is zero.
    if (out == NULL || input == NULL || out_sz == 0)
    {
        return -1;
    }

    // Starting off with an empty output string.
    out[0] = '\0';

    // This sequence of code removes newline characters from the end of the input
    // since fgets()  stores '\n' due to the user pressing the Enter key!
    length = strlen(input);
    while (length > 0 && (input[length - 1] == '\n'))
    {
        input[length - 1] = '\0';
        length--;
    }

    // If the user typed normal text (not starting with '/'), it turns it into a MSG command!
    if (input[0] != '/')
    {
        build_msg_command(out, out_sz, input);
        return 0;
    }

    // Make user input lowercase for command
    int inputLen = strlen(input);
    char temp[1024];

    memset(temp, 0, sizeof(temp)); // clear temp array

    for (int i = 0; i < inputLen; i++)
    {
        if (input[i] != ' ')
        {
            temp[i] = tolower(input[i]);
        }
    }

    // If the user typed exactly "/who" command!
    if (strcmp(temp, "/who") == 0)
    {
        build_simple_command(out, out_sz, CMD_WHO);
        return 0;
    }

    // If the user typed exactly "/quit"
    if (strcmp(temp, "/quit") == 0)
    {
        build_simple_command(out, out_sz, CMD_QUIT);
        return 0;
    }

    if (strncmp(input, "/ping"
                       " ",
                strlen("/ping") + 1) == 0)
    {
        build_ping_command(out, out_sz, input + strlen("/ping") + 1);
        return 0;
    }

    // If the user typed the '/dm' command with anything else after that. For example: "/dm Bob pizza"
    if (strcmp(temp, "/dm") == 0)
    {
        // variable declarations
        char nick[MAX_NICK_LENGTH];
        char message[MAX_LINE];
        char curr;
        int space_counter = 0;
        int nick_counter = 0;
        int msg_counter = 0;
        int curr_counter = 0;

        // clear previously used arrays
        memset(nick, 0, sizeof(nick));
        memset(message, 0, sizeof(message));

        while (space_counter < 3)
        {
            curr = input[curr_counter];

            // end once null terminator is found
            if (curr == '\0')
            {
                space_counter = 3;
            }

            // adds characters to message array
            if (space_counter == 2)
            {
                message[msg_counter] = curr;
                msg_counter++;
            }

            // add characters to nick array
            if (space_counter == 1)
            {
                if (curr == ' ')
                {
                    space_counter++;
                }
                else
                {
                    nick[nick_counter] = curr;
                    nick_counter++;
                }
            }

            // ignore characters that belong to the command
            if (space_counter == 0 && (curr == ' '))
            {
                space_counter++;
            }

            curr_counter++;
        }

        build_dm_command(out, out_sz, message, nick);
        return 0;
    }

    if (strncmp(input, "/nick"
                       " ",
                strlen("/nick") + 1) == 0)
    {
        build_nick_command(out, out_sz, input + strlen("/nick") + 1);
        return 0;
    }

    if (strncmp(input, "/msg"
                       " ",
                strlen("/msg") + 1) == 0)
    {
        build_msg_command(out, out_sz, input + strlen("/msg") + 1);
        return 0;
    }

    // Another safety check if none of the commands matched or work at all!
    return -1;

}
