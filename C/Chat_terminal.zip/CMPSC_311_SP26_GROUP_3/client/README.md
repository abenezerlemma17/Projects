# Client

Build: `make`
Run: `./chat_server <host> <port> <nick>`
