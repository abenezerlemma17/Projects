#ifndef CLIENT_H
#define CLIENT_H

#include <pthread.h>
#include <stdbool.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "../shared/protocol.h"

extern volatile sig_atomic_t shutdown_requested;

struct client
{
    int fd;
    char nick[MAX_NICK_LENGTH + 1];
    int has_nick;
    int connected;
    struct sockaddr_in addr;
    pthread_t thread;
    struct client *next;
};

typedef void (*client_iter_fn)(struct client *c, void *ctx);

void *client_thread_main(void *arg);
void client_init(struct client *c, int fd, const struct sockaddr_in *addr);
void client_close(struct client *c);
int client_set_nick(struct client *c, const char *nick);
extern pthread_mutex_t clients_mutex;
extern struct client *client_head;  /* Head of the global clients list */
void clients_add(struct client *c);
void clients_remove(struct client *c);
struct client *clients_find_by_nick(const char *nick);
void clients_for_each(client_iter_fn fn, void *ctx);
void clients_request_shutdown_all(void);
void client_request_shutdown(struct client *client);
void clients_wait_for_empty(void);

#endif