#include "log_queue.h"
#include "../../shared/util.h"

#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

pthread_mutex_t log_queue_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t log_queue_cond = PTHREAD_COND_INITIALIZER;
int log_queue_shutdown_requested = 0;

/* Protected by log_queue_mutex. */
static struct log_event *queue_head = NULL;
static struct log_event *queue_tail = NULL;
static size_t current_queue_size = 0;

int logger_init(void)
{
    pthread_mutex_lock(&log_queue_mutex);
    queue_head = NULL;
    queue_tail = NULL;
    current_queue_size = 0;
    log_queue_shutdown_requested = 0;
    pthread_mutex_unlock(&log_queue_mutex);

    return 0;
}

int enqueue_log_event(const char *event_text)
{
    struct log_event *event;

    if (event_text == NULL)
    {
        errno = EINVAL;
        return -1;
    }

    event = malloc(sizeof(*event));
    if (event == NULL)
    {
        errno = ENOMEM;
        return -1;
    }

    memset(event, 0, sizeof(*event));
    strncpy(event->line, event_text, sizeof(event->line) - 1);
    event->next = NULL;

    pthread_mutex_lock(&log_queue_mutex);

    if (log_queue_shutdown_requested)
    {
        pthread_mutex_unlock(&log_queue_mutex);
        free(event);
        errno = ECANCELED;
        return -1;
    }

    if (queue_tail == NULL)
    {
        queue_head = event;
        queue_tail = event;
    }
    else
    {
        queue_tail->next = event;
        queue_tail = event;
    }

    current_queue_size++;

    /* Wake the consumer after successfully enqueueing. */
    pthread_cond_signal(&log_queue_cond);
    pthread_mutex_unlock(&log_queue_mutex);

    return 0;
}

void *logger_thread_main(void *arg)
{
    (void)arg;

    int log_fd = open(LOG_FILE, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (log_fd < 0)
    {
        die("open server.log");
    }

    for (;;)
    {
        struct log_event *batch_head;
        struct log_event *event;

        pthread_mutex_lock(&log_queue_mutex);

        /*
         * Sleep while there is nothing to do.
         * Wake either for new work or shutdown.
         */
        while (queue_head == NULL && !log_queue_shutdown_requested)
        {
            pthread_cond_wait(&log_queue_cond, &log_queue_mutex);
        }

        /*
         * Clean shutdown path:
         * if shutdown was requested and the queue is empty, exit the thread.
         */
        if (queue_head == NULL && log_queue_shutdown_requested)
        {
            pthread_mutex_unlock(&log_queue_mutex);
            break;
        }

        /* Detach all currently queued events so producers can keep enqueueing. */
        batch_head = queue_head;
        queue_head = NULL;
        queue_tail = NULL;
        current_queue_size = 0;

        pthread_mutex_unlock(&log_queue_mutex);

        event = batch_head;
        while (event != NULL)
        {
            struct log_event *next = event->next;

            if (write(log_fd, event->line, strlen(event->line)) < 0)
            {
                free(event);
                close(log_fd);
                die("write server.log");
            }

            /* Ensure exactly one line is written per event. */
            if (event->line[0] != '\0' && event->line[strlen(event->line) - 1] != '\n')
            {
                if (write(log_fd, "\n", 1) < 0)
                {
                    free(event);
                    close(log_fd);
                    die("write server.log newline");
                }
            }

            free(event);
            event = next;
        }
    }

    close(log_fd);

    pthread_mutex_lock(&log_queue_mutex);
    while (queue_head != NULL)
    {
        struct log_event *next = queue_head->next;
        free(queue_head);
        queue_head = next;
    }
    queue_tail = NULL;
    current_queue_size = 0;
    pthread_mutex_unlock(&log_queue_mutex);

    return NULL;
}

int logger_shutdown(void)
{
    /*
     * Request shutdown and wake the consumer.
     * The logger thread should be joined by the caller after this.
     * Once the consumer exits, it can safely stop using the queue.
     */
    pthread_mutex_lock(&log_queue_mutex);
    log_queue_shutdown_requested = 1;
    pthread_cond_broadcast(&log_queue_cond);
    pthread_mutex_unlock(&log_queue_mutex);

    return 0;
}
