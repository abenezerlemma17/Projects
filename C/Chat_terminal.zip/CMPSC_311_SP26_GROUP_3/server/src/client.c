#include "client.h"
#include "../shared/net.h"
#include "../shared/util.h"
#include "../shared/protocol.h"
#include "broadcast.h"
#include "log_queue.h"
#include "protocol.h"
#include "stats.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void *client_thread_main(void *arg)
{
    struct client *c = (struct client *)arg;
    int sockfd;

    if (c == NULL)
    {
        return NULL;
    }

    sockfd = c->fd;

    char buf[MAX_LINE * 2];
    size_t buf_len = 0;
    char out[MAX_LINE];
    ssize_t bytes;
    int should_exit = 0;

    memset(buf, 0, sizeof(buf));

    while (!shutdown_requested)
    {

        bytes = recv(sockfd, buf + buf_len, sizeof(buf) - 1 - buf_len, 0);

        if (bytes == 0)
        {
            break;
        }
        if (bytes < 0)
        {
            if (errno == EINTR)
            {
                if (shutdown_requested)
                {
                    break;
                }
                continue;
            }
            // Any other recv error means the client connection is broken
            break;
        }

        buf_len += (size_t)bytes;
        buf[buf_len] = '\0';

        while (extract_line(buf, &buf_len, out, sizeof(out)) > 0)
        {
            if (protocol_handle_line(c, out) == 1)
            {
                should_exit = 1;
                break;
            }
        }

        if (should_exit)
        {
            break;
        }

        if (buf_len == sizeof(buf) - 1)
        {
            buf_len = 0;
            buf[0] = '\0';
        }
    }

    clients_remove(c);
    client_close(c);
    free(c);
    return NULL;
}

void client_init(struct client *c, int fd, const struct sockaddr_in *addr)
{
    if (c == NULL)
    {
        return;
    }

    c->fd = fd;        // If there isn't a socket present or available!
    c->nick[0] = '\0'; // If there's an empty string!
    c->has_nick = 0;   // Nickname wasn't set yet!
    c->connected = (fd >= 0) ? 1 : 0;

    if (addr != NULL)
    {
        c->addr = *addr; // This line of code copies the address of the socket
    }
    else
    { 
        memset(&c->addr, 0, sizeof(c->addr));
    }

    memset(&c->thread, 0, sizeof(c->thread));
    c->next = NULL;
}

// This block of code closes the client connection and reset its state!
void client_close(struct client *c)
{
    if (c == NULL)
    {
        return;
    }

    if (c->fd >= 0)
    {
        close(c->fd);
    }

    c->fd = -1;
    c->nick[0] = '\0';
    c->has_nick = 0;
    c->connected = 0;
    memset(&c->addr, 0, sizeof(c->addr));
    memset(&c->thread, 0, sizeof(c->thread));
    c->next = NULL;
}

// This code section sets up the client nickname if it's valid!
int client_set_nick(struct client *c, const char *nick)
{
    size_t length;

    if (c == NULL || nick == NULL)
    {
        return -1;
    }
    
    length = strlen(nick);

    // Safety handles for empty names inserted or really long names*/
    if (length == 0 || length > MAX_NICK_LENGTH)
    {
        return -1;
    }

    pthread_mutex_lock(&clients_mutex);
    // This line of code copies the nickname stored in 'c' into 'has_nick'!
    memcpy(c->nick, nick, length + 1);
    c->has_nick = 1;

    pthread_mutex_unlock(&clients_mutex);
    return 0;
}

struct client *client_head = NULL;
pthread_mutex_t clients_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t clients_empty_cond = PTHREAD_COND_INITIALIZER;

void clients_add(struct client *c)
{
    if (c == NULL)
    {
        return;
    }

    pthread_mutex_lock(&clients_mutex);
    c->next = client_head;
    client_head = c;
    pthread_mutex_unlock(&clients_mutex);
}

void clients_remove(struct client *c)
{
    if (c == NULL)
    {
        return;
    }

    pthread_mutex_lock(&clients_mutex);
    if (client_head == c)
    {
        client_head = c->next;
    }
    else
    {
        struct client *prev = client_head;
        while (prev != NULL && prev->next != c)
        {
            prev = prev->next;
        }
        if (prev != NULL && prev->next == c)
        {
            prev->next = c->next;
        }
    }

    if (client_head == NULL)
    {
        pthread_cond_broadcast(&clients_empty_cond);
    }

    pthread_mutex_unlock(&clients_mutex);
}
struct client *clients_find_by_nick(const char *nick)
{
    struct client *found_client = NULL;

    if (nick == NULL)
    {
        return NULL;
    }

    pthread_mutex_lock(&clients_mutex);
    struct client *current = client_head;

    while (current != NULL)
    {
        if (strcmp(current->nick, nick) == 0)
        {
            found_client = current;
            break;
        }
        current = current->next;
    }

    pthread_mutex_unlock(&clients_mutex);
    return found_client; // Returns the client that currently has the nickname inputted
}

void clients_for_each(client_iter_fn fn, void *ctx)
{
    struct client *current;

    if (fn == NULL)
    {
        return;
    }

    pthread_mutex_lock(&clients_mutex);
    current = client_head;
    while (current != NULL)
    {
        fn(current, ctx);
        current = current->next;
    }
    pthread_mutex_unlock(&clients_mutex);
}

void clients_request_shutdown_all(void)
{
    struct client *current;

    pthread_mutex_lock(&clients_mutex);
    current = client_head;
    while (current != NULL)
    {
        if (current->fd >= 0)
        {
            shutdown(current->fd, SHUT_RDWR);
        }
        current = current->next;
    }
    pthread_mutex_unlock(&clients_mutex);
}

void client_request_shutdown(struct client *client)
{
    char msg[MAX_LINE];
    char log_line[MAX_LINE];
    char ip_addr[INET_ADDRSTRLEN] = {0};

    shutdown(client->fd, SHUT_RDWR);

    // Logs when an ip disconnects due to a nickname already taken
    while (inet_ntop(AF_INET, &client->addr.sin_addr, ip_addr, sizeof(ip_addr)) == NULL)
    {
        continue;
    }
    snprintf(msg, sizeof(msg), "DISCONNECT %s:%u", ip_addr, (unsigned)ntohs(client->addr.sin_port));
    if (format_log_line(log_line, sizeof(log_line), msg) == 1)
    {
        enqueue_log_event(log_line);
    }
}

void clients_wait_for_empty(void)
{
    pthread_mutex_lock(&clients_mutex);
    while (client_head != NULL)
    {
        pthread_cond_wait(&clients_empty_cond, &clients_mutex);
    }
    pthread_mutex_unlock(&clients_mutex);
}
