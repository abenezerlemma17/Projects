#include "broadcast.h"
#include "client.h"
#include "../../shared/net.h"

#include <string.h>

int broadcast_line(const char *line, const struct client *exclude)
{
    if (line == NULL)
    {
        return -1;
    }

    size_t count = 0;

    extern pthread_mutex_t clients_mutex;
    extern struct client *client_head;

    pthread_mutex_lock(&clients_mutex);

    for (struct client *c = client_head; c != NULL && count < MAX_CLIENTS; c = c->next)
    {
        // Skip the excluded client
        if (exclude != NULL && c == exclude)
        {
            continue;
        }
        
        send_line(c->fd, line);
    
    }
    pthread_mutex_unlock(&clients_mutex);

    return 0;
}
