#include "protocol.h"
#include "broadcast.h"
#include "log_queue.h"
#include "stats.h"
#include "../shared/net.h"
#include "../shared/util.h"
#include "client.h"
#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <ctype.h>
#include <arpa/inet.h>
#include <time.h>

// Before the fix, protocol.c didn't handle NICK or MSG commands (creating the ERR 406)!
// Now the bug is fixed!

int protocol_handle_line(struct client *client, const char *line)
{
    char msg[MAX_LINE];
    char tmp[MAX_LINE];
    char cmd[32];
    char log_line[MAX_LINE];
    char ip_addr[INET_ADDRSTRLEN] = {0};
    char *rest;
    struct client *existing_client;

    if (client == NULL || line == NULL)
    {
        return -1;
    }

    // This line of code creates a writable copy of the line and remove any Carriage Return/Line Feed
    // characters from the end of the string.
    snprintf(tmp, sizeof(tmp), "%s", line);
    chomp_crlf(tmp);

    // Read the first word into cmd.
    if (sscanf(tmp, "%31s", cmd) != 1)
    {
        return 0;
    }

    // This block of code handles NICK commands!
    if (strcmp(cmd, CMD_NICK) == 0)
    {
        rest = tmp + strlen(cmd);
        trim_spaces(rest);

        if (!valid_nick(rest))
        {
            snprintf(msg, sizeof(msg), "%s %d: Invalid Nickname", RSP_ERR, ERR_INVALID_NICK);
            send_line(client->fd, msg);

            // The nickname originally inputted is invalid
            if(client->nick[0] == '\0')
            {
                client_request_shutdown(client);
            }
            return 0;
        }

        // Sorts through all currently connected clients and determines whether the inputted nickname is available
        existing_client = clients_find_by_nick(rest);
        if (existing_client != NULL && existing_client != client)
        {
            snprintf(msg, sizeof(msg), "%s %d: Nickname Already In Use", RSP_ERR, ERR_NICK_IN_USE);
            send_line(client->fd, msg);

            // The nickname originally inputted is already taken
            if(client->nick[0] == '\0')
            {
                client_request_shutdown(client);
            }
            return 0;
        }

        if(client->nick[0] == '\0') // Nick by default is empty so this checks if it's empty and if it is, then that means the user has just connected
        {
            snprintf(msg, sizeof(msg), "CONNECTED: %s", rest);
            broadcast_line(msg, client);
        }

        if(client->nick[0] != '\0') // This checks if nick is populated, if it is then that means the user already has one and is changing
        {
            snprintf(msg, sizeof(msg), "NICK: %s->%s", client->nick, rest);
            broadcast_line(msg, client);
        }

        // Logs when a user inputs a nickname along with their chosen nickname and ip info
        while (inet_ntop(AF_INET, &client->addr.sin_addr, ip_addr, sizeof(ip_addr)) == NULL)
        {
            continue;
        }
        snprintf(msg, sizeof(msg), "%s %s %s:%u", CMD_NICK, rest, ip_addr, (unsigned)ntohs(client->addr.sin_port));
        if (format_log_line(log_line, sizeof(log_line), msg) == 1)
        {
            enqueue_log_event(log_line);
        }
        
        // Sets the inputted nickname for the client
        if (client_set_nick(client, rest) != 0)
        {
            snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_INVALID_NICK);
            send_line(client->fd, msg);
            return 0;
        }
        
        return 0;
    }
    // END OF NICK command handle!

    // This block of code handles MSG commands!
    if (strcmp(cmd, CMD_MSG) == 0)
    {

        rest = tmp + strlen(cmd);
        trim_spaces(rest);

        if (!client->has_nick)
        {
            snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_NOT_REGISTERED);
            send_line(client->fd, msg);
            return 0;
        }

        if (rest[0] == '\0' || strlen(rest) > MAX_MESSAGE_LENGTH)
        {
            snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_MESSAGE_TOO_LONG);
            send_line(client->fd, msg);
            return 0;
        }

        // Build a broadcast line like: MSG alice hello everyone.
        // ADDED THE TIME FOR THE BROADCAST!

        time_t now = time(NULL);
        struct tm *tm_info = localtime(&now);
        char timestamp[16];
        strftime(timestamp, sizeof(timestamp), "%H:%M:%S", tm_info);

        snprintf(msg, sizeof(msg), "[%s] %s: %s", timestamp, client->nick, rest); // Timestamp included between clients 

        broadcast_line(msg, client);        

        snprintf(msg, sizeof(msg), "%s %s %s", CMD_MSG, client->nick, rest); // Timestamp removed when logging

        // Logs whenever a message is sent along with who sent it and what was sent
        if (format_log_line(log_line, sizeof(log_line), msg) == 1)
        {
            enqueue_log_event(log_line);
        }
        return 0;
    }
    // END OF MSG command handle!

    // This block will handle the DM command
    if (strcmp(cmd, CMD_DM) == 0)
    {

        rest = tmp + strlen(cmd);
        trim_spaces(rest);

        if (!client->has_nick)
        {
            snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_NOT_REGISTERED);
            send_line(client->fd, msg);
            return 0;
        }

        // variable declarations
        char nick[MAX_NICK_LENGTH];
        char msg_to_send[MAX_LINE];
        char curr = '\n';
        int space_counter = 0;
        int nick_counter = 0;
        int msg_counter = 0;
        int curr_counter = 0;

        // clear previously used arrays
        memset(nick, 0, sizeof(nick));
        memset(msg_to_send, 0, sizeof(msg_to_send));

        // separate nick from message
        while (curr != '\0')
        {
            curr = rest[curr_counter];

            if (space_counter == 1)
            {
                msg_to_send[msg_counter] = curr;
                msg_counter++;
            }

            if (space_counter == 0 && (curr == ' '))
            {
                space_counter++;
            }

            if (space_counter == 0 && !(curr == ' '))
            {
                nick[nick_counter] = curr;
                nick_counter++;
            }

            curr_counter++;
        }

        if (msg_to_send[0] == '\0' || nick[0] == '\0')
        {
            snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_UNKNOWN_COMMAND);
            send_line(client->fd, msg);
            return 0;
        }

        if (strcmp(nick, client->nick) == 0)
        {
            snprintf(msg, sizeof(msg), "You cannot message yourself");
            send_line(client->fd, msg);
            return 0;
        }

        struct client *client_to_dm;
        client_to_dm = clients_find_by_nick(nick);

        if (client_to_dm == NULL)
        {
            snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_NO_SUCH_USER);
            send_line(client->fd, msg);
            return 0;
        }

        if (rest[0] == '\0' || strlen(rest) > MAX_MESSAGE_LENGTH)
        {
            snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_MESSAGE_TOO_LONG);
            send_line(client->fd, msg);
            return 0;
        }

        time_t now = time(NULL);
        struct tm *tm_info = localtime(&now);
        char timestamp[16];
        strftime(timestamp, sizeof(timestamp), "%H:%M:%S", tm_info);

        // Build a broadcast line like: MSG alice hello everyone
        snprintf(msg, sizeof(msg), "[%s] %s %s: %s", timestamp, CMD_DM, client->nick, msg_to_send); // Timestamp included between clients 

        send_line(client_to_dm->fd, msg);

        snprintf(msg, sizeof(msg), "%s %s->%s %s", CMD_DM, client->nick, client_to_dm->nick, msg_to_send); // Timestamp removed when logging

        // Logs whenever a message is sent along with who sent it and what was sent
        if (format_log_line(log_line, sizeof(log_line), msg) == 1)
        {
            enqueue_log_event(log_line);
        }
        return 0;
    }

    if (strcmp(cmd, CMD_QUIT) == 0)
    {

        // Logs when and who disconnected
        while (inet_ntop(AF_INET, &client->addr.sin_addr, ip_addr, sizeof(ip_addr)) == NULL)
        {
            continue;
        }
        snprintf(msg, sizeof(msg), "DISCONNECT %s %s:%u", client->nick, ip_addr, (unsigned)ntohs(client->addr.sin_port));
        if (format_log_line(log_line, sizeof(log_line), msg) == 1)
        {
            enqueue_log_event(log_line);
        }

        // Public message that user has disconnected
        snprintf(msg, sizeof(msg), "DISCONNECTED: %s", client->nick);
        broadcast_line(msg, client);

        return 1;
    }

    if (strcmp(cmd, CMD_WHO) == 0)
    {
        // Logs when a user runs the WHO command and who ran it
        while (inet_ntop(AF_INET, &client->addr.sin_addr, ip_addr, sizeof(ip_addr)) == NULL)
        {
            continue;
        }
        snprintf(msg, sizeof(msg), "%s %s %s:%u", CMD_WHO, client->nick, ip_addr, (unsigned)ntohs(client->addr.sin_port));
        if (format_log_line(log_line, sizeof(log_line), msg) == 1)
        {
            enqueue_log_event(log_line);
        }

        // For loop starts at head of client list and prints each connected client with thier nickname to the client that called the command
        snprintf(msg, sizeof(msg), "Users: ");
        for (struct client *c = client_head; c != NULL; c = c->next)
        {
            snprintf(tmp, sizeof(tmp), "%s, ", c->nick);
            strcat(msg, tmp); 
        }
        send_line(client->fd, msg);
        return 0;
    }

    if (strcmp(cmd, CMD_PING) == 0)
    {
        rest = tmp + strlen(cmd);
        trim_spaces(rest);

        // Logs when a user runs the WHO command and who ran it
        while (inet_ntop(AF_INET, &client->addr.sin_addr, ip_addr, sizeof(ip_addr)) == NULL)
        {
            continue;
        }
        snprintf(msg, sizeof(msg), "%s %s %s:%u", CMD_PING, client->nick, ip_addr, (unsigned)ntohs(client->addr.sin_port));
        if (format_log_line(log_line, sizeof(log_line), msg) == 1)
        {
            enqueue_log_event(log_line);
        }

        snprintf(msg, sizeof(msg), "%s %s", RSP_PONG, rest);
        send_line(client->fd, msg);
        return 0;
    }

    snprintf(msg, sizeof(msg), "%s %d", RSP_ERR, ERR_UNKNOWN_COMMAND);
    send_line(client->fd, msg);
    return 0;
}
