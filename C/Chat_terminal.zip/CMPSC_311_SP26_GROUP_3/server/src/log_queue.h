#ifndef LOG_QUEUE_H
#define LOG_QUEUE_H

#include <pthread.h>
#include <stdbool.h>
#include <stddef.h>

#define LOG_FILE "server.log"

struct log_event
{
    char line[512];
    struct log_event *next;
};

extern pthread_mutex_t log_queue_mutex;
extern pthread_cond_t log_queue_cond;
extern int log_queue_shutdown_requested;

/* Setup / teardown helpers */
int logger_init(void);
int logger_shutdown(void);

/* Producer / consumer entry points */
int enqueue_log_event(const char *event_text);
void *logger_thread_main(void *arg);

#endif
