#ifndef BROADCAST_H
#define BROADCAST_H

#include "client.h"

int broadcast_line(const char *line, const struct client *exclude);

#endif
