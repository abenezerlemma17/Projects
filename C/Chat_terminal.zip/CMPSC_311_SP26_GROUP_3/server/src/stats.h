#ifndef STATS_H
#define STATS_H

#include <time.h>
#include <pthread.h>

#endif
