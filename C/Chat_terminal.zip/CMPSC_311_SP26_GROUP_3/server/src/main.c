#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <limits.h>
#include <string.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include "log_queue.h"
#include "client.h"
#include "broadcast.h"
#include "../shared/util.h"

// Global shutdown flag
volatile sig_atomic_t shutdown_requested = 0;

// Signal handler
void handle_shutdown_signal(int sig)
{
    (void)sig;
    shutdown_requested = 1;
}

static void install_signal_handlers(void)
{
    struct sigaction sa;

    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_shutdown_signal;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    if (sigaction(SIGINT, &sa, NULL) != 0)
    {
        die("sigaction SIGINT");
    }
    if (sigaction(SIGTERM, &sa, NULL) != 0)
    {
        die("sigaction SIGTERM");
    }
}

struct producer_args
{
    const char *tag;
    int count;
};

static void *fake_client_thread_main(void *arg)
{
    (void)arg;
    struct timespec ts;

    printf("[selftest] fake client thread start\n");
    ts.tv_sec = 0;
    ts.tv_nsec = 20000000L;
    nanosleep(&ts, NULL);
    printf("[selftest] fake client thread exit\n");
    return NULL;
}

static void *log_producer_main(void *arg)
{
    struct producer_args *pa = (struct producer_args *)arg;
    char line[256];

    for (int i = 0; i < pa->count; i++)
    {
        if (snprintf(line, sizeof(line), "%s event %d\n", pa->tag, i + 1) > 0)
        {
            enqueue_log_event(line);
        }
    }

    return NULL;
}

static int file_contains(const char *path, const char *needle)
{
    FILE *f;
    char buf[1024];

    f = fopen(path, "r");
    if (f == NULL)
    {
        return 0;
    }

    while (fgets(buf, sizeof(buf), f) != NULL)
    {
        if (strstr(buf, needle) != NULL)
        {
            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;
}

static int run_self_tests(void)
{
    pthread_t logger_thread;
    pthread_t fake_client_thread;
    pthread_t prod_a;
    pthread_t prod_b;
    struct producer_args pa = {"P1", 5};
    struct producer_args pb = {"P2", 5};
    struct client c1;
    struct client c2;
    int pair1[2] = {-1, -1};
    int pair2[2] = {-1, -1};
    char rbuf[128] = {0};
    int ok = 1;

    printf("[selftest] starting\n");
    unlink(LOG_FILE);

    if (pthread_create(&fake_client_thread, NULL, fake_client_thread_main, NULL) != 0)
    {
        perror("selftest fake client thread");
        return 1;
    }
    pthread_join(fake_client_thread, NULL);

    client_init(&c1, -1, NULL);
    client_init(&c2, -1, NULL);
    client_set_nick(&c1, "dummy1");
    client_set_nick(&c2, "dummy2");
    clients_add(&c1);
    clients_add(&c2);
    if (clients_find_by_nick("dummy1") == NULL || clients_find_by_nick("dummy2") == NULL)
    {
        printf("[selftest] list add/find failed\n");
        ok = 0;
    }
    clients_remove(&c1);
    clients_remove(&c2);

    if (socketpair(AF_UNIX, SOCK_STREAM, 0, pair1) != 0 || socketpair(AF_UNIX, SOCK_STREAM, 0, pair2) != 0)
    {
        perror("selftest socketpair");
        return 1;
    }

    client_init(&c1, pair1[0], NULL);
    client_init(&c2, pair2[0], NULL);
    client_set_nick(&c1, "b1");
    client_set_nick(&c2, "b2");
    clients_add(&c1);
    clients_add(&c2);

    broadcast_line("SELFTEST_BROADCAST", NULL);

    memset(rbuf, 0, sizeof(rbuf));
    if (recv(pair1[1], rbuf, sizeof(rbuf) - 1, 0) <= 0 || strstr(rbuf, "SELFTEST_BROADCAST") == NULL)
    {
        printf("[selftest] broadcast receive failed for socket 1\n");
        ok = 0;
    }
    memset(rbuf, 0, sizeof(rbuf));
    if (recv(pair2[1], rbuf, sizeof(rbuf) - 1, 0) <= 0 || strstr(rbuf, "SELFTEST_BROADCAST") == NULL)
    {
        printf("[selftest] broadcast receive failed for socket 2\n");
        ok = 0;
    }

    clients_remove(&c1);
    clients_remove(&c2);
    close(pair1[0]);
    close(pair1[1]);
    close(pair2[0]);
    close(pair2[1]);

    if (logger_init() != 0)
    {
        printf("[selftest] logger_init failed\n");
        return 1;
    }

    if (pthread_create(&logger_thread, NULL, logger_thread_main, NULL) != 0)
    {
        perror("selftest logger thread");
        return 1;
    }

    pthread_create(&prod_a, NULL, log_producer_main, &pa);
    pthread_create(&prod_b, NULL, log_producer_main, &pb);
    pthread_join(prod_a, NULL);
    pthread_join(prod_b, NULL);

    enqueue_log_event("SELFTEST_FINAL_1\n");
    enqueue_log_event("SELFTEST_FINAL_2\n");
    enqueue_log_event("SELFTEST_FINAL_3\n");

    logger_shutdown();
    pthread_join(logger_thread, NULL);

    if (!file_contains(LOG_FILE, "P1 event 1") || !file_contains(LOG_FILE, "P2 event 1"))
    {
        printf("[selftest] producer logging verification failed\n");
        ok = 0;
    }

    if (!file_contains(LOG_FILE, "SELFTEST_FINAL_1") ||
        !file_contains(LOG_FILE, "SELFTEST_FINAL_2") ||
        !file_contains(LOG_FILE, "SELFTEST_FINAL_3"))
    {
        printf("[selftest] shutdown-drain verification failed\n");
        ok = 0;
    }

    printf("[selftest] %s\n", ok ? "PASS" : "FAIL");
    return ok ? 0 : 1;
}

int main(int argc, char *argv[])
{
    int sockfd, client_fd;
    int port;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);
    char log_line[1024];

    pthread_t logger_thread;

    if (argc == 2 && strcmp(argv[1], "--selftest") == 0)
    {
        return run_self_tests();
    }

    if (argc != 2)
    {
        errno = EINVAL;
        die("Usage: ./chat_server <port>");
    }

    {
        char *end = NULL;
        long parsed;

        errno = 0;
        parsed = strtol(argv[1], &end, 10);
        if (errno != 0 || end == argv[1] || *end != '\0' || parsed < 1 || parsed > 65535)
        {
            errno = EINVAL;
            die("Invalid port");
        }
        port = (int)parsed;
    }

    // Setup signal handlers
    install_signal_handlers();

    // Initialize logger
    if (logger_init() != 0)
    {
        die("logger_init");
    }

    // Start logger thread
    {
        int rc = pthread_create(&logger_thread, NULL, logger_thread_main, NULL);
        if (rc != 0)
        {
            errno = rc;
            die("pthread_create logger");
        }
    }

    if (format_log_line(log_line, sizeof(log_line), "START server thread initialized") == 1)
    {
        enqueue_log_event(log_line);
    }

    // Setup server socket
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        die("socket");
    }

    // Allow immediate reuse of the port after restart
    {
        int opt = 1;
        if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
        {
            close(sockfd);
            die("setsockopt SO_REUSEADDR");
        }
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        close(sockfd);
        die("bind");
    }

    if (listen(sockfd, 5) < 0)
    {
        close(sockfd);
        die("listen");
    }

    printf("Server listening on port %d...\n", port);

    // Accept loop
    while (!shutdown_requested)
    {
        client_fd = accept(sockfd, (struct sockaddr *)&client_addr, &client_len);

        if (client_fd < 0)
        {
            if (shutdown_requested)
                break;
            if (errno == EINTR)
            {
                continue;
            }
            perror("accept");
            continue;
        }

        struct client *client = malloc(sizeof(*client));
        if (client == NULL)
        {
            perror("malloc client");
            close(client_fd);
            continue;
        }

        client_init(client, client_fd, &client_addr);
        clients_add(client);

        {
            char addr_text[INET_ADDRSTRLEN] = {0};
            char connect_event[256];

            while (inet_ntop(AF_INET, &client_addr.sin_addr, addr_text, sizeof(addr_text)) == NULL)
            {
                continue;
            }
            snprintf(connect_event, sizeof(connect_event), "CONNECT %s:%u", addr_text, (unsigned)ntohs(client_addr.sin_port));

            if (format_log_line(log_line, sizeof(log_line), connect_event) == 1)
            {
                enqueue_log_event(log_line);
            }
        }

        // Set detach state before thread creation to avoid the race window
        // between pthread_create and pthread_detach
        {
            pthread_attr_t attr;
            pthread_attr_init(&attr);
            pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
            int rc = pthread_create(&client->thread, &attr, client_thread_main, client);
            pthread_attr_destroy(&attr);
            if (rc != 0)
            {
                perror("pthread_create client");
                clients_remove(client);
                close(client_fd);
                free(client);
                continue;
            }
        }
    }

    // Shutdown server
    printf("\nShutting down server...\n");
    shutdown_requested = 1;
    close(sockfd);
    clients_request_shutdown_all();
    clients_wait_for_empty();

    if (format_log_line(log_line, sizeof(log_line), "SHUTDOWN server stopping") == 1)
    {
        enqueue_log_event(log_line);
    }

    // Shutdown logger
    logger_shutdown();
    pthread_join(logger_thread, NULL);

    printf("Shutdown complete.\n");

    return 0;
}