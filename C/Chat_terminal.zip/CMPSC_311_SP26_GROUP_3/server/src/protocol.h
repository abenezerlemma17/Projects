#ifndef PROTOCOL_H
#define PROTOCOL_H

#include "client.h"
#include "../shared/protocol.h"

int protocol_handle_line(struct client *client, const char *line);

#endif
