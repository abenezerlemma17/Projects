# Server

Build: `make`
Run: `./chat_server <port>`
